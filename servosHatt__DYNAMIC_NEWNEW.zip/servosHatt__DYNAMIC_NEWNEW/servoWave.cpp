#include "servoWave.h"
//#include <Metro.h>

//Metro metro = Metro(servoWave.period);

//constructor with four argiuments about the wave
ServoWave::ServoWave() {

  //try define
  //preprocessor 
}
ServoWave::~ServoWave() {
  delete servoPositions;
  delete servos;
}

ServoWave::ServoWave(int _numServos, int _angle, unsigned long _period, int _wavelength, int _ampMax){

  numServos = _numServos;//servos of the whole unit
  angle = _angle;//height of wave 
  period = _period; //in milliseconds
  wavelength = _wavelength;//how many servos long the wave will be
  ampMax=_ampMax;
  //long unsigned periodBis = period;
float p = 0;
  int total = int(TWO_PI/0.01);//total num of index pioints, until the amplitude is back at zero

  //initialize the servos
  //servoPositions = new int[numServos];
  //initializr the servo array
  //servos = new Servo[numServos];
  int numServos = _numServos;
  //set currentServo to 0
  int currentServo = 0;
  int lastPosition=-1;
  int steps = 5;
  long previousMillis = 0;
  long lastUpdatedAt = millis();

  float wave[total];


  //initialize servoPosition array
  for(int i=0;i<numServos;i++){//wtf
    servoPositions[i] = 90; // starting position for all servos. could be passed as an argument 
    //(angle)
  }
  
   p = 0;
for(int i=0;i<total;i++){
 wave[i] = map(sin(p), -1,1,0,180);
p+=0.05;//THIS IS WHA T NMUST INFLUENCE SPEED

}
for(int i=0;i<numServos;i++){
 index[i] = i*2;//CHANGE THIS FOR CHANGING THE DIFFERENCE BETEWWEEN THEM
 }
}

void ServoWave::addServo(Servo servo){
  servos[currentServo]=servo;
  currentServo++; 
}

void ServoWave::addServo(Servo servo, int startingPosition){
  servos[currentServo]=servo;
  servoPositions[currentServo] = startingPosition;
  currentServo++; 
}

void ServoWave::update(){
for(int i=0;i<numServos;i++){
 angle  = wave[index[i]];
 index[i] = (index[i]+1)%total;
 Serial.print(angle);
}

}

void ServoWave::move(){



}

int ServoWave::calculateAngle(){
}
void ServoWave::passDownValues(int firstValue){

  for (int i=16;i>0;i--){
    servoAngles[i] = servoAngles[i-1];
  }
  servoAngles[0]=firstValue;

}

void ServoWave::adjustServos(int curA){
  servos[currentServo].write(servoAngles[currentServo]);

  currentServo++;
  if(currentServo>numServos-1){
    currentServo=0;
    passDownValues(curA); 
  }
}

